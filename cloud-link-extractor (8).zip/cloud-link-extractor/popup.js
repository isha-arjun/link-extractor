(function () {
  "use strict";

  const scanPageBtn = document.getElementById("scanPageBtn");
  const crawlBtn = document.getElementById("crawlBtn");
  const checkBtn = document.getElementById("checkBtn");
  const stopBtn = document.getElementById("stopBtn");
  const downloadBtn = document.getElementById("downloadBtn");
  const clearBtn = document.getElementById("clearBtn");
  const statusEl = document.getElementById("status");
  const emptyEl = document.getElementById("empty");
  const listEl = document.getElementById("linkList");

  /** @type {{url: string, host: string, access?: "ok"|"no"|"unknown"}[]} */
  let foundLinks = [];
  let stopRequested = false;
  const MAX_PAGES = 600;
  const TAB_TIMEOUT_MS = 10000;
  const ACCESS_TIMEOUT_MS = 9000;
  const ACCESS_CONCURRENCY = 3;

  const ALLOWED_HOST_PATTERNS = [
    /(^|\.)docs\.google\.com$/i,
    /(^|\.)drive\.google\.com$/i,
    /(^|\.)sheets\.google\.com$/i,
    /(^|\.)slides\.google\.com$/i,
    /(^|\.)forms\.google\.com$/i,
    /(^|\.)classroom\.google\.com$/i,
    /(^|\.)sites\.google\.com$/i,
    /(^|\.)drawings\.google\.com$/i,
    /(^|\.)jamboard\.google\.com$/i,
    /(^|\.)meet\.google\.com$/i,
    /(^|\.)calendar\.google\.com$/i,
    /(^|\.)google\.com$/i,
    /(^|\.)googleusercontent\.com$/i,
    /(^|\.)canva\.com$/i,
    /(^|\.)onedrive\.live\.com$/i,
    /^1drv\.ms$/i,
    /(^|\.)sharepoint\.com$/i,
    /(^|\.)office\.com$/i,
    /(^|\.)office365\.com$/i,
    /(^|\.)microsoft\.com$/i,
    /(^|\.)live\.com$/i,
    /(^|\.)dropbox\.com$/i,
    /(^|\.)box\.com$/i,
    /(^|\.)padlet\.com$/i,
    /(^|\.)miro\.com$/i,
    /(^|\.)figma\.com$/i,
    /(^|\.)youtube\.com$/i,
    /^youtu\.be$/i,
    /(^|\.)vimeo\.com$/i,
    /(^|\.)kahoot\.(com|it)$/i,
    /(^|\.)quizizz\.com$/i,
    /(^|\.)nearpod\.com$/i,
    /(^|\.)peardeck\.com$/i,
    /(^|\.)genially\.com$/i,
    /(^|\.)prezi\.com$/i,
    /(^|\.)notion\.so$/i,
    /(^|\.)notion\.site$/i,
    /(^|\.)bit\.ly$/i,
    /(^|\.)tinyurl\.com$/i,
    /(^|\.)trello\.com$/i,
    /(^|\.)airtable\.com$/i,
    /(^|\.)flip\.com$/i,
    /(^|\.)flipgrid\.com$/i,
    /(^|\.)edpuzzle\.com$/i,
    /(^|\.)bookcreator\.com$/i,
    /(^|\.)seesaw\.me$/i,
    /(^|\.)screencastify\.com$/i,
    /(^|\.)loom\.com$/i,
    /(^|\.)wetransfer\.com$/i
  ];

  const FILE_EXTENSIONS = [
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "pps", "ppsx",
    "zip", "rar", "7z", "tar", "gz", "tgz",
    "mp3", "mp4", "mov", "avi", "wmv", "mkv", "wav", "m4a",
    "jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "ico",
    "csv", "txt", "rtf", "odt", "ods", "odp",
    "exe", "dmg", "pkg", "apk", "msi",
    "pages", "numbers", "key"
  ];
  const FILE_EXT_RE = new RegExp(
    "\\.(?:" + FILE_EXTENSIONS.join("|") + ")(?:$|[?#])",
    "i"
  );
  const DOWNLOAD_PATH_RE = /\/(download|downloads|attachment|attachments|export)(\/|$|\?)/i;

  // Phrases that usually mean the user cannot open the resource
  const NO_ACCESS_PHRASES = [
    "you need access",
    "request access",
    "you don't have permission",
    "you do not have permission",
    "you don't have access",
    "you do not have access",
    "access denied",
    "permission denied",
    "sign in to continue",
    "sign in to view",
    "sign in to open",
    "this file is private",
    "this item is private",
    "sorry, the file you have requested does not exist",
    "file is in owner's trash",
    "you need permission",
    "ask for access",
    "contact the owner",
    "unable to access",
    "no access",
    "not authorized",
    "authorization required",
    "login required",
    "please sign in",
    "choose an account",
    "who has access",
    "shared with you? ask for access"
  ];

  function getHost(url) {
    try {
      const u = new URL(url);
      if (u.protocol === "file:") return "local-file";
      return u.hostname.replace(/^www\./, "") || "unknown";
    } catch {
      return "unknown";
    }
  }

  function looksLikeFileDownload(url) {
    try {
      const u = new URL(url);
      if (FILE_EXT_RE.test(u.pathname) || FILE_EXT_RE.test(u.href)) return true;
      if (/[?&]export=download\b/i.test(u.search)) return true;
      if (DOWNLOAD_PATH_RE.test(u.pathname)) return true;
      return false;
    } catch {
      return true;
    }
  }

  function hostIsAllowed(hostname) {
    const host = hostname.replace(/^www\./, "").toLowerCase();
    return ALLOWED_HOST_PATTERNS.some((re) => re.test(host));
  }

  function isAllowedExternalLink(url) {
    try {
      const u = new URL(url);
      if (u.protocol !== "http:" && u.protocol !== "https:") return false;
      const host = u.hostname.replace(/^www\./, "").toLowerCase();
      if (
        /instructure\.com$/i.test(host) ||
        /canvas\.com$/i.test(host) ||
        /canvaslms\.com$/i.test(host) ||
        host === "localhost" ||
        host === "127.0.0.1"
      ) {
        return false;
      }
      if (!hostIsAllowed(host)) return false;
      if (looksLikeFileDownload(url)) return false;
      return true;
    } catch {
      return false;
    }
  }

  function setStatus(msg, isError = false) {
    statusEl.innerHTML = msg;
    statusEl.style.color = isError ? "var(--danger)" : "var(--muted)";
  }

  function setBusy(busy) {
    scanPageBtn.disabled = busy;
    crawlBtn.disabled = busy;
    checkBtn.disabled = busy;
    stopBtn.style.display = busy ? "inline-block" : "none";
    if (!busy) stopRequested = false;
  }

  function noAccessCount() {
    return foundLinks.filter((l) => l.access === "no").length;
  }

  function renderList() {
    listEl.innerHTML = "";
    if (foundLinks.length === 0) {
      emptyEl.style.display = "block";
      listEl.style.display = "none";
      downloadBtn.style.display = "none";
      checkBtn.style.display = "none";
      return;
    }
    emptyEl.style.display = "none";
    listEl.style.display = "block";
    checkBtn.style.display = "inline-block";

    const denied = noAccessCount();
    downloadBtn.style.display = denied > 0 ? "inline-block" : "none";

    // Prefer showing no-access first if any checks ran
    const sorted = foundLinks.slice().sort((a, b) => {
      const order = { no: 0, unknown: 1, ok: 2 };
      const ao = order[a.access || "unknown"] ?? 1;
      const bo = order[b.access || "unknown"] ?? 1;
      if (ao !== bo) return ao - bo;
      if (a.host !== b.host) return a.host.localeCompare(b.host);
      return a.url.localeCompare(b.url);
    });

    sorted.forEach(({ url, host, access }) => {
      const li = document.createElement("li");
      const badge = document.createElement("span");
      badge.className = "badge";
      if (access === "no") {
        badge.classList.add("noaccess");
        badge.textContent = "no access";
      } else if (access === "ok") {
        badge.classList.add("ok");
        badge.textContent = "ok";
      } else {
        badge.textContent = host;
      }
      badge.title = host;
      const a = document.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = url;
      li.appendChild(badge);
      li.appendChild(a);
      listEl.appendChild(li);
    });
  }

  function collectFromDocument() {
    const results = new Set();
    document.querySelectorAll("a[href]").forEach((a) => {
      try {
        const href = a.href || "";
        if (
          href.startsWith("http://") ||
          href.startsWith("https://") ||
          href.startsWith("file://")
        ) {
          results.add(href.split("#")[0]);
        }
      } catch (_) {}
    });
    document.querySelectorAll("iframe[src], embed[src], object[data]").forEach((el) => {
      try {
        const src =
          el.src || el.data || el.getAttribute("src") || el.getAttribute("data") || "";
        if (
          src.startsWith("http://") ||
          src.startsWith("https://") ||
          src.startsWith("file://")
        ) {
          results.add(src.split("#")[0]);
        }
      } catch (_) {}
    });
    const bodyText = document.body ? document.body.innerText : "";
    const urlRegex = /https?:\/\/[^\s"'<>\]]+/gi;
    let match;
    while ((match = urlRegex.exec(bodyText)) !== null) {
      const u = match[0].replace(/[.,;:!?)\]]+$/, "");
      if (u.startsWith("http")) results.add(u.split("#")[0]);
    }
    return Array.from(results);
  }

  /**
   * Injected into a resource tab to decide access.
   * Returns { status: "ok"|"no"|"unknown", reason: string, finalUrl: string }
   */
  /**
   * Injected into a resource tab to decide access.
   * Aggressive Google Drive / Docs / Canva / OneDrive denial detection.
   * Returns { status: "ok"|"no"|"unknown", reason: string, finalUrl: string }
   */
  function inspectAccess() {
    const finalUrl = location.href || "";
    const title = (document.title || "").toLowerCase();
    const bodyText = (document.body ? document.body.innerText : "") || "";
    const body = bodyText.toLowerCase().slice(0, 20000);
    const html = (document.documentElement ? document.documentElement.innerHTML : "").toLowerCase().slice(0, 50000);

    // --- Login / account walls ---
    if (
      /accounts\.google\.com/i.test(finalUrl) ||
      /login\.microsoftonline\.com/i.test(finalUrl) ||
      /login\.live\.com/i.test(finalUrl) ||
      /canva\.com\/(login|signup)/i.test(finalUrl) ||
      /ServiceLogin/i.test(finalUrl) ||
      /signin/i.test(finalUrl) && /google\.com/i.test(finalUrl)
    ) {
      return { status: "no", reason: "login/accounts page", finalUrl };
    }

    // --- Strong phrase list (title + body + raw html) ---
    const phrases = [
      "you need access",
      "you need permission",
      "request access",
      "ask for access",
      "you don't have access",
      "you do not have access",
      "you don't have permission",
      "you do not have permission",
      "don't have permission",
      "do not have permission",
      "no access",
      "access denied",
      "permission denied",
      "access is denied",
      "unable to access",
      "can't access",
      "cannot access",
      "not authorized",
      "unauthorized",
      "authorization required",
      "this file is private",
      "this item is private",
      "this document is private",
      "file is in the owner's trash",
      "file is in owner's trash",
      "has been deleted",
      "sorry, the file you have requested does not exist",
      "the file you have requested does not exist",
      "could not find the requested",
      "sign in to continue",
      "sign in to view",
      "sign in to open",
      "sign in to see",
      "please sign in",
      "choose an account",
      "shared with you? ask for access",
      "you need access to this item",
      "you need access to view",
      "contact the owner",
      "ask the owner",
      "owner has not granted",
      "restricted",
      "you may need to sign in",
      "to view this document",
      "to view this file",
      "viewer permissions",
      "need to request access"
    ];

    for (const p of phrases) {
      if (title.indexOf(p) !== -1 || body.indexOf(p) !== -1 || html.indexOf(p) !== -1) {
        return { status: "no", reason: "phrase: " + p, finalUrl };
      }
    }

    // --- Google Drive / Docs specific DOM signals ---
    const isGoogle =
      /drive\.google\.com|docs\.google\.com|sheets\.google\.com|slides\.google\.com|forms\.google\.com/i.test(
        finalUrl
      );

    if (isGoogle) {
      // Buttons / labels
      const nodes = document.querySelectorAll("button, a, div, span, h1, h2, [role='button'], [aria-label]");
      for (const el of nodes) {
        const t = ((el.innerText || "") + " " + (el.getAttribute("aria-label") || "")).toLowerCase();
        if (
          t.indexOf("request access") !== -1 ||
          t.indexOf("ask for access") !== -1 ||
          t.indexOf("you need access") !== -1 ||
          t.indexOf("need access") !== -1
        ) {
          return { status: "no", reason: "google UI: " + t.slice(0, 60), finalUrl };
        }
      }

      // Common Drive denial container class patterns / data attributes
      if (
        html.indexOf("request-access") !== -1 ||
        html.indexOf("requestaccess") !== -1 ||
        html.indexOf("needs_auth") !== -1 ||
        html.indexOf("autherror") !== -1 ||
        html.indexOf("accessdenied") !== -1 ||
        html.indexOf("access-denied") !== -1
      ) {
        return { status: "no", reason: "google html marker", finalUrl };
      }

      // Title patterns used by Drive when blocked
      if (
        /access denied|request access|sign in|permission/i.test(document.title || "")
      ) {
        return { status: "no", reason: "google title: " + (document.title || ""), finalUrl };
      }

      // If still on file/doc URL but body is very short (often denial shell before hydrate)
      // Give a second signal: look for "Google Drive" chrome without editor UI
      const hasEditor =
        html.indexOf("docs-texteventtarget-iframe") !== -1 ||
        html.indexOf("office-icon") !== -1 ||
        document.querySelector('[aria-label*="File" i]') ||
        document.querySelector("#docs-editor") ||
        document.querySelector(".drive-viewer") ||
        bodyText.length > 800;
      if (!hasEditor && bodyText.length < 500) {
        // Ambiguous — mark unknown rather than false ok
        return { status: "unknown", reason: "google thin page", finalUrl };
      }
    }

    // Canva denial
    if (/canva\.com/i.test(finalUrl)) {
      if (
        body.indexOf("don't have access") !== -1 ||
        body.indexOf("do not have access") !== -1 ||
        body.indexOf("request access") !== -1 ||
        body.indexOf("ask for access") !== -1 ||
        html.indexOf("request-access") !== -1
      ) {
        return { status: "no", reason: "canva denial", finalUrl };
      }
    }

    // OneDrive / SharePoint
    if (/onedrive|1drv\.ms|sharepoint/i.test(finalUrl)) {
      if (
        body.indexOf("you don't have permission") !== -1 ||
        body.indexOf("you need permission") !== -1 ||
        body.indexOf("access denied") !== -1 ||
        body.indexOf("sign in") !== -1 && body.indexOf("permission") !== -1
      ) {
        return { status: "no", reason: "onedrive denial", finalUrl };
      }
    }

    if (body.trim().length < 30 && title.trim().length < 3) {
      return { status: "unknown", reason: "empty page", finalUrl };
    }

    return { status: "ok", reason: "no denial signals", finalUrl };
  }

  function processResults(urls) {
    const seen = new Set();
    foundLinks = [];
    for (const url of urls) {
      if (!isAllowedExternalLink(url)) continue;
      if (seen.has(url)) continue;
      seen.add(url);
      foundLinks.push({ url, host: getHost(url), access: undefined });
    }
    foundLinks.sort((a, b) => {
      if (a.host !== b.host) return a.host.localeCompare(b.host);
      return a.url.localeCompare(b.url);
    });
    renderList();
  }

  async function getActiveTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) throw new Error("No active tab found.");
    if (
      tab.url &&
      (tab.url.startsWith("chrome://") ||
        tab.url.startsWith("chrome-extension://") ||
        tab.url.startsWith("https://chrome.google.com/webstore") ||
        tab.url.startsWith("edge://") ||
        tab.url.startsWith("about:"))
    ) {
      throw new Error("Cannot scan this type of page (browser internal).");
    }
    return tab;
  }

  function normalizeUrl(url) {
    try {
      return new URL(url).href.split("#")[0];
    } catch {
      return url.split("#")[0];
    }
  }

  function isHtmlCandidate(url) {
    try {
      const path = new URL(url).pathname.toLowerCase();
      const last = path.split("/").pop() || "";
      return (
        path.endsWith(".html") ||
        path.endsWith(".htm") ||
        path.endsWith("/") ||
        last === "" ||
        !last.includes(".")
      );
    } catch {
      return false;
    }
  }

  function makeIsInternal(startUrl) {
    const start = new URL(startUrl);
    if (start.protocol === "file:") {
      const parts = start.pathname.split("/").filter(Boolean);
      const baseDir = parts.slice(0, -1).join("/");
      return (url) => {
        try {
          const u = new URL(url);
          if (u.protocol !== "file:") return false;
          return u.pathname.indexOf(baseDir) !== -1;
        } catch {
          return false;
        }
      };
    }
    return (url) => {
      try {
        return new URL(url).origin === start.origin;
      } catch {
        return false;
      }
    };
  }

  function waitForTabLoad(tabId, timeoutMs) {
    return new Promise((resolve) => {
      let done = false;
      const timer = setTimeout(() => {
        if (done) return;
        done = true;
        chrome.tabs.onUpdated.removeListener(listener);
        resolve("timeout");
      }, timeoutMs);

      function listener(id, info) {
        if (id !== tabId) return;
        if (info.status === "complete") {
          if (done) return;
          done = true;
          clearTimeout(timer);
          chrome.tabs.onUpdated.removeListener(listener);
          resolve("complete");
        }
      }
      chrome.tabs.onUpdated.addListener(listener);

      chrome.tabs.get(tabId).then((t) => {
        if (t.status === "complete" && !done) {
          done = true;
          clearTimeout(timer);
          chrome.tabs.onUpdated.removeListener(listener);
          resolve("complete");
        }
      }).catch(() => {});
    });
  }

  async function collectFromTab(tabId) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        func: collectFromDocument
      });
      return results?.[0]?.result || [];
    } catch (err) {
      console.warn("collectFromTab failed", tabId, err);
      return [];
    }
  }

  function countAllowed(set) {
    let n = 0;
    for (const u of set) if (isAllowedExternalLink(u)) n++;
    return n;
  }

  async function scanCurrentPageOnly() {
    setBusy(true);
    setStatus("Scanning current page…");
    try {
      const tab = await getActiveTab();
      const urls = await collectFromTab(tab.id);
      processResults(urls);
      setStatus(
        foundLinks.length
          ? `Found <span class="count">${foundLinks.length}</span> allowed link${foundLinks.length === 1 ? "" : "s"}. Click “Check access” next.`
          : "No matching links on this page."
      );
    } catch (err) {
      console.error(err);
      setStatus("Error: " + (err.message || String(err)), true);
    } finally {
      setBusy(false);
    }
  }

  async function crawlAll() {
    setBusy(true);
    stopRequested = false;
    setStatus("Starting crawl…");

    const allLinks = new Set();
    const visited = new Set();
    const queue = [];
    let pagesScanned = 0;
    let errors = 0;

    try {
      const startTab = await getActiveTab();
      const startUrl = normalizeUrl(startTab.url || "");
      if (!startUrl) throw new Error("Could not read current page URL.");

      const isInternal = makeIsInternal(startUrl);

      const seedLinks = await collectFromTab(startTab.id);
      seedLinks.forEach((u) => allLinks.add(normalizeUrl(u)));
      visited.add(startUrl);
      pagesScanned = 1;

      seedLinks.forEach((u) => {
        const n = normalizeUrl(u);
        if (isInternal(n) && isHtmlCandidate(n) && !visited.has(n)) {
          queue.push(n);
        }
      });

      setStatus(
        `Page 1 · queue ${queue.length} · kept <span class="count">${countAllowed(allLinks)}</span>`
      );

      while (queue.length > 0 && pagesScanned < MAX_PAGES && !stopRequested) {
        const nextUrl = queue.shift();
        if (visited.has(nextUrl)) continue;
        visited.add(nextUrl);
        pagesScanned++;

        setStatus(
          `Scanning page <span class="count">${pagesScanned}</span> · queue ${queue.length} · kept <span class="count">${countAllowed(allLinks)}</span><br><span style="font-size:11px;opacity:0.85">${nextUrl.replace(/^file:\/\//, "").slice(-80)}</span>`
        );

        let tabId = null;
        try {
          const tab = await chrome.tabs.create({ url: nextUrl, active: false });
          tabId = tab.id;
          await waitForTabLoad(tabId, TAB_TIMEOUT_MS);
          await new Promise((r) => setTimeout(r, 200));

          const pageLinks = await collectFromTab(tabId);
          for (const raw of pageLinks) {
            const n = normalizeUrl(raw);
            allLinks.add(n);
            if (
              isInternal(n) &&
              isHtmlCandidate(n) &&
              !visited.has(n) &&
              !queue.includes(n)
            ) {
              queue.push(n);
            }
          }
        } catch (err) {
          console.warn("Failed page", nextUrl, err);
          errors++;
        } finally {
          if (tabId != null) {
            try {
              await chrome.tabs.remove(tabId);
            } catch (_) {}
          }
        }
      }

      processResults(Array.from(allLinks));

      const stopped = stopRequested;
      setStatus(
        `Crawled <span class="count">${pagesScanned}</span> page${pagesScanned === 1 ? "" : "s"}` +
          (errors ? ` (${errors} error${errors === 1 ? "" : "s"})` : "") +
          ` → <span class="count">${foundLinks.length}</span> kept link${foundLinks.length === 1 ? "" : "s"}` +
          (stopped ? " (stopped early)" : "") +
          ". Click “Check access” next."
      );
    } catch (err) {
      console.error(err);
      setStatus("Error during crawl: " + (err.message || String(err)), true);
      if (allLinks.size) processResults(Array.from(allLinks));
    } finally {
      setBusy(false);
    }
  }

  async function checkAccess() {
    if (foundLinks.length === 0) {
      setStatus("No links to check. Crawl or scan first.", true);
      return;
    }

    setBusy(true);
    stopRequested = false;

    // Reset previous access flags so re-check is clean
    foundLinks.forEach((l) => { l.access = undefined; });
    renderList();

    let checked = 0;
    let denied = 0;
    let ok = 0;
    let unknown = 0;
    const total = foundLinks.length;
    let nextIndex = 0;

    async function checkOne(item) {
      let tabId = null;
      try {
        const tab = await chrome.tabs.create({ url: item.url, active: false });
        tabId = tab.id;
        const loadState = await waitForTabLoad(tabId, ACCESS_TIMEOUT_MS);
        // Short settle for client-rendered denial UI
        await new Promise((r) => setTimeout(r, loadState === "timeout" ? 250 : 450));

        let result = { status: "unknown", reason: "script failed", finalUrl: item.url };
        try {
          const injected = await chrome.scripting.executeScript({
            target: { tabId },
            func: inspectAccess
          });
          if (injected?.[0]?.result) result = injected[0].result;
        } catch (err) {
          const tabInfo = await chrome.tabs.get(tabId).catch(() => null);
          const fu = tabInfo?.url || item.url;
          if (
            /accounts\.google\.com|ServiceLogin|login\.microsoftonline\.com|login\.live\.com|canva\.com\/(login|signup)/i.test(
              fu
            )
          ) {
            result = { status: "no", reason: "login page", finalUrl: fu };
          } else {
            result = { status: "unknown", reason: String(err.message || err), finalUrl: fu };
          }
        }

        item.access = result.status === "no" ? "no" : result.status === "ok" ? "ok" : "unknown";
        return item.access;
      } catch (err) {
        console.warn("check failed", item.url, err);
        item.access = "unknown";
        return "unknown";
      } finally {
        if (tabId != null) {
          try { await chrome.tabs.remove(tabId); } catch (_) {}
        }
      }
    }

    function updateStatus() {
      setStatus(
        `Checking access <span class="count">${checked}</span> / ${total}` +
          ` · no-access <span class="count">${denied}</span>` +
          ` · ok ${ok} · unknown ${unknown}`
      );
    }

    try {
      const workers = [];
      const concurrency = Math.max(1, Math.min(ACCESS_CONCURRENCY || 3, 4));

      async function worker() {
        while (!stopRequested) {
          const i = nextIndex++;
          if (i >= total) break;
          const item = foundLinks[i];
          const status = await checkOne(item);
          checked++;
          if (status === "no") denied++;
          else if (status === "ok") ok++;
          else unknown++;
          if (checked % 2 === 0 || checked === total) {
            updateStatus();
            renderList();
          }
        }
      }

      for (let w = 0; w < concurrency; w++) workers.push(worker());
      await Promise.all(workers);

      renderList();
      const stopped = stopRequested;
      setStatus(
        `Access check done` +
          (stopped ? " (stopped early)" : "") +
          `: <span class="count">${denied}</span> no access · ${ok} ok · ${unknown} unknown` +
          (denied ? ". Download the no-access HTML." : ".")
      );
    } catch (err) {
      console.error(err);
      setStatus("Error during access check: " + (err.message || String(err)), true);
      renderList();
    } finally {
      setBusy(false);
    }
  }

  function requestStop() {
    stopRequested = true;
    setStatus("Stop requested… finishing current item.");
  }

  function downloadNoAccessHtml() {
    const denied = foundLinks.filter((l) => l.access === "no");
    if (denied.length === 0) {
      setStatus("No “no access” links to export. Run Check access first.", true);
      return;
    }

    const byHost = {};
    denied.forEach(({ url, host }) => {
      if (!byHost[host]) byHost[host] = [];
      byHost[host].push(url);
    });
    const hosts = Object.keys(byHost).sort();
    const generated = new Date().toISOString();
    const dateLabel = generated.slice(0, 10);

    function esc(s) {
      return String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    }

    let sections = "";
    hosts.forEach((host) => {
      const links = byHost[host];
      const items = links
        .map(
          (u) =>
            `        <li><a href="${esc(u)}" target="_blank" rel="noopener noreferrer">${esc(u)}</a></li>`
        )
        .join("\n");
      sections += `
    <section class="group">
      <h2>${esc(host)} <span class="count">${links.length}</span></h2>
      <ul>
${items}
      </ul>
    </section>`;
    });

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>No-Access Links — ${esc(dateLabel)}</title>
<style>
:root{--bg:#f6f8fa;--card:#fff;--accent:#1a73e8;--text:#1f2328;--muted:#656d76;--border:#d0d7de;--danger:#cf222e}
*{box-sizing:border-box}
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:var(--bg);color:var(--text);line-height:1.5}
header{background:var(--danger);color:#fff;padding:1.25rem 1.5rem}
header h1{margin:0;font-size:1.35rem}
header p{margin:0.35rem 0 0;opacity:0.9;font-size:0.95rem}
main{max-width:900px;margin:0 auto;padding:1.5rem}
.summary{display:flex;flex-wrap:wrap;gap:0.75rem;margin-bottom:1.5rem}
.summary span{background:var(--card);border:1px solid var(--border);border-radius:6px;padding:0.4rem 0.75rem;font-size:0.9rem}
.group{background:var(--card);border:1px solid var(--border);border-radius:8px;padding:1rem 1.15rem;margin-bottom:1rem}
.group h2{margin:0 0 0.6rem;font-size:1.05rem;display:flex;align-items:center;gap:0.5rem}
.group h2 .count{font-size:0.8rem;font-weight:600;color:var(--muted);background:#eef1f4;padding:0.15rem 0.5rem;border-radius:999px}
ul{list-style:none;margin:0;padding:0}
li{padding:0.35rem 0;border-top:1px solid #eef1f4;word-break:break-all;font-size:0.9rem}
li:first-child{border-top:none}
a{color:var(--accent);text-decoration:none}
a:hover{text-decoration:underline}
footer{text-align:center;padding:1.5rem;color:var(--muted);font-size:0.85rem}
.search{width:100%;max-width:360px;padding:0.55rem 0.75rem;border:1px solid var(--border);border-radius:6px;font-size:1rem;margin-bottom:1.25rem}
</style>
</head>
<body>
<header>
  <h1>Links without access</h1>
  <p>Checked with your current Chrome session · ${esc(generated)}</p>
</header>
<main>
  <div class="summary">
    <span>No-access links: <strong>${denied.length}</strong></span>
    <span>Hosts: <strong>${hosts.length}</strong></span>
  </div>
  <input class="search" type="search" id="q" placeholder="Filter links…" autocomplete="off">
${sections}
</main>
<footer>Generated by Link Extractor — only links that showed “need access / request access / sign in”</footer>
<script>
(function(){
  var q=document.getElementById("q");
  if(!q)return;
  q.addEventListener("input",function(){
    var term=(q.value||"").toLowerCase();
    document.querySelectorAll(".group").forEach(function(sec){
      var any=false;
      sec.querySelectorAll("li").forEach(function(li){
        var show=!term||li.textContent.toLowerCase().indexOf(term)!==-1;
        li.style.display=show?"":"none";
        if(show)any=true;
      });
      sec.style.display=any?"":"none";
    });
  });
})();
</script>
</body>
</html>`;

    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "no-access-links-" + dateLabel + ".html";
    a.click();
    URL.revokeObjectURL(url);
  }

  function clearList() {
    foundLinks = [];
    renderList();
    setStatus("List cleared.");
  }

  scanPageBtn.addEventListener("click", scanCurrentPageOnly);
  crawlBtn.addEventListener("click", crawlAll);
  checkBtn.addEventListener("click", checkAccess);
  stopBtn.addEventListener("click", requestStop);
  downloadBtn.addEventListener("click", downloadNoAccessHtml);
  clearBtn.addEventListener("click", clearList);
})();
